<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['staff_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Fetch all orders
$stmt = $pdo->prepare("
    SELECT o.order_id, o.table_number, o.order_time, o.status, e.name AS emp_name 
    FROM `order` o 
    LEFT JOIN employee e ON o.emp_id = e.emp_id
");
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h1 class="text-center mb-4">Staff Dashboard</h1>

        <?php if (isset($_SESSION['staff_logged_in'])): ?>
            <div class="alert alert-info text-center">Logged in as: <?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?> (Staff)</div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h2 class="h4 mb-0">All Orders</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Order Number</th>
                                <th>Table Number</th>
                                <th>Time</th>
                                <th>Items</th>
                                <th>Status</th>
                                <th>Employee</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($order['order_id']); ?></td>
                                    <td><?php echo htmlspecialchars($order['table_number']); ?></td>
                                    <td><?php echo htmlspecialchars($order['order_time']); ?></td>
                                    <td>
                                        <?php 
                                            $stmt = $pdo->prepare("SELECT mi.quantity, m.name 
                                                                   FROM menu mi 
                                                                   JOIN menu_item m ON mi.menu_item_id = m.menu_item_id 
                                                                   WHERE mi.order_id = ?");
                                            $stmt->execute([$order['order_id']]);
                                            $orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            $itemNames = array_map(function($item) {
                                                return htmlspecialchars($item['name']) . ' x' . htmlspecialchars($item['quantity']);
                                            }, $orderItems);
                                            echo implode(", ", $itemNames);
                                        ?>
                                    </td>
                                    <td><span class="status-<?php echo htmlspecialchars($order['status']); ?>"><?php echo htmlspecialchars($order['status']); ?></span></td>
                                    <td><?php echo htmlspecialchars($order['emp_name'] ?? ''); ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
