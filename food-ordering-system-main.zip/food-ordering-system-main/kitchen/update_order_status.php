<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

// Check if kitchen or admin is logged in
if (!isset($_SESSION['kitchen_logged_in']) && !isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Check if order_id and status are sent via GET
if (isset($_GET['order_id'], $_GET['status'])) {
    $order_id = intval($_GET['order_id']);
    $status = $_GET['status'];

    try {
        $pdo->beginTransaction();

        // Update order status, completion time, and emp_id in the database
        $stmt = $pdo->prepare("UPDATE `order` SET status = ?, completion_time = NOW(), emp_id = ? WHERE order_id = ?");
        
        // Use session variable storing the current user's emp_id
        $emp_id = $_SESSION['user_id'] ?? null;

        if (!$stmt->execute([$status, $emp_id, $order_id])) {
            throw new Exception("Failed to update order status.");
        }

        // Check if any order was updated
        if ($stmt->rowCount() === 0) {
            throw new Exception("No order was updated, possibly the order ID does not exist.");
        }

        $pdo->commit();

        // Redirect back to kitchen dashboard
        header('Location: kitchen_dashboard.php');
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Error: " . $e->getMessage());
    }
} else {
    // Error message if order_id or status are not provided
    die("Order ID and Status are required.");
}
?>
