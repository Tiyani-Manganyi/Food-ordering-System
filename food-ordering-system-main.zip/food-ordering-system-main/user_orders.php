<?php
include 'includes/db.php';
session_start();

$table_number = isset($_GET['table_id']) ? intval($_GET['table_id']) : 0;

if ($table_number <= 0) {
    die("Invalid table number");
}

try {
    $stmt = $pdo->prepare('
        SELECT o.order_id, o.table_number, o.order_time, o.status, mi.menu_item_id, mi.quantity, m.name, m.price 
        FROM `order` o 
        JOIN menu mi ON o.table_number = mi.table_number 
        JOIN menu_item m ON mi.menu_item_id = m.menu_item_id 
        WHERE o.table_number = ? 
        ORDER BY o.order_id DESC');
    $stmt->execute([$table_number]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}

// Group order items by order ID
$groupedOrders = [];
foreach ($orders as $order) {
    $order_id = $order['order_id'];
    $table_number = $order['table_number'];
    if (!isset($groupedOrders[$table_number])) {
        $groupedOrders[$table_number] = [];
    }
    if (!isset($groupedOrders[$table_number][$order_id])) {
        $groupedOrders[$table_number][$order_id] = [
            'order_id' => $order_id,
            'table_number' => $table_number,
            'order_time' => $order['order_time'],
            'status' => $order['status'],
            'items' => []
        ];
    }
    $groupedOrders[$table_number][$order_id]['items'][] = [
        'name' => $order['name'],
        'quantity' => $order['quantity'],
        'price' => $order['price']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill for Table <?php echo htmlspecialchars($table_number); ?></title>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="node_modules/@fortawesome/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .receipt-container {
            margin-bottom: 20px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .receipt-header {
            margin-bottom: 20px;
        }
        .receipt-items table {
            width: 100%;
        }
        .receipt-items th, .receipt-items td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        .receipt-footer {
            text-align: right;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Bill for Table: <?php echo htmlspecialchars($table_number); ?></h1>
        <div id="receiptContainer"></div>
    </div>
    <script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="node_modules/@fortawesome/fontawesome-free/js/all.min.js"></script>
    <script>
        // JavaScript variable from PHP data
        const groupedOrders = <?php echo json_encode($groupedOrders); ?>;

        function renderReceipts(orders) {
            const receiptContainer = document.getElementById('receiptContainer');
            for (const table_number in orders) {
                for (const order_id in orders[table_number]) {
                    const order = orders[table_number][order_id];
                    const receiptDiv = document.createElement('div');
                    receiptDiv.classList.add('receipt-container');
                    let itemsHtml = '';
                    let total = 0;
                    order.items.forEach(item => {
                        const itemTotal = item.quantity * item.price;
                        total += itemTotal;
                        itemsHtml += `
                            <tr>
                                <td>${item.name}</td>
                                <td>${item.quantity}</td>
                                <td>${item.price} ZAR</td>
                                <td>${itemTotal.toFixed(2)} ZAR</td>
                            </tr>
                        `;
                    });

                    receiptDiv.innerHTML = `
                        <div class="receipt-header">
                            <h5>Order ID: ${order.order_id}</h5>
                            <p>Table Number: ${order.table_number}</p>
                            <p>Order Time: ${order.order_time}</p>
                            <p>Status: <span class="badge ${getBadgeClass(order.status)}">${order.status}</span></p>
                        </div>
                        <div class="receipt-items">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Menu Item</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${itemsHtml}
                                </tbody>
                            </table>
                        </div>
                        <div class="receipt-footer">
                            <h5>Total Price: ${total.toFixed(2)} ZAR</h5>
                        </div>
                    `;
                    receiptContainer.appendChild(receiptDiv);
                }
            }
        }

        function getBadgeClass(status) {
            switch (status) {
                case 'pending':
                    return 'badge-warning';
                case 'preparing':
                    return 'badge-info';
                case 'completed':
                    return 'badge-success';
                case 'cancelled':
                    return 'badge-danger';
                default:
                    return '';
            }
        }

        renderReceipts(groupedOrders);
    </script>
</body>
</html>
