<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: ../admin/login.php');
    exit();
}

// Get table_number from GET parameters
$table_number = $_GET['id'];

try {
    // Check if table exists
    $stmt = $pdo->prepare("SELECT * FROM qr_code WHERE table_number = ?");
    $stmt->execute([$table_number]);
    $table = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$table) {
        throw new Exception('Table not found.');
    }

    // Delete the table from database
    $stmt = $pdo->prepare("DELETE FROM qr_code WHERE table_number = ?");
    $stmt->execute([$table_number]);

    // Redirect to manage_tables.php after successful deletion
    header('Location: manage_tables.php');
    exit();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
