<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

// Check admin login
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: ../admin/login.php');
    exit();
}

// Add table
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $table_number = $_POST['table_number'];
    $max_capacity = $_POST['max_capacity'];
    $status = $_POST['status'];

    try {
        // Check if table number is unique
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM qr_code WHERE table_number = ?");
        $stmt->execute([$table_number]);
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            throw new Exception('This table number already exists');
        }

        // Generate URL for QR Code linking to menu selection page
        $baseUrl = 'http://' . $_SERVER['HTTP_HOST'] . str_replace('/tables', '', dirname($_SERVER['PHP_SELF'])) . '/index.php';
        $tableData = $baseUrl . '?table_id=' . $table_number;
        $qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' . urlencode($tableData);

        // Save table data to database
        $stmt = $pdo->prepare("INSERT INTO qr_code (table_number, max_capacity, status, qr_code) VALUES (?, ?, ?, ?)");
        $stmt->execute([$table_number, $max_capacity, $status, $qrUrl]);

        header('Location: manage_tables.php');
        exit();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Table</title>
    <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../admin/layout/navbar.php'; ?>
    <div class="container mt-5">
        <h1 class="text-center">Add Table</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        <form action="add_table.php" method="POST">
            <div class="mb-3">
                <label for="table_number" class="form-label">Table Number</label>
                <input type="number" class="form-control" id="table_number" name="table_number" required>
            </div>
            <div class="mb-3">
                <label for="max_capacity" class="form-label">Maximum Capacity</label>
                <input type="number" class="form-control" id="max_capacity" name="max_capacity" required>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="available">Available</option>
                    <option value="occupied">Occupied</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>
    <script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
