<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: ../admin/login.php');
    exit();
}

// Initialize variables
$id = $_GET['id'];
$error = '';

// Fetch table data for editing
$stmt = $pdo->prepare("SELECT * FROM qr_code WHERE table_number = ?");
$stmt->execute([$id]);
$table = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if table exists
if (!$table) {
    die("Table not found.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $max_capacity = $_POST['max_capacity'];
    $status = $_POST['status'];

    try {
        // Update table data
        $stmt = $pdo->prepare("UPDATE qr_code SET max_capacity = ?, status = ? WHERE table_number = ?");
        $stmt->execute([$max_capacity, $status, $id]);

        // Redirect to manage_tables.php after successful update
        header('Location: manage_tables.php');
        exit();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Table</title>
    <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../admin/layout/navbar.php'; ?>
    <div class="container mt-5">
        <h1 class="text-center">Edit Table</h1>
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        <form action="edit_table.php?id=<?php echo $id; ?>" method="POST">
            <div class="mb-3">
                <label for="max_capacity" class="form-label">Maximum Capacity</label>
                <input type="number" class="form-control" id="max_capacity" name="max_capacity" value="<?php echo htmlspecialchars($table['max_capacity']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="available" <?php if ($table['status'] == 'available') echo 'selected'; ?>>Available</option>
                    <option value="occupied" <?php if ($table['status'] == 'occupied') echo 'selected'; ?>>Occupied</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    </div>
    <script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
