<?php
session_start();
include '../includes/db.php';
include 'functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Example data retrieval from the database
$menuCount = $pdo->query("SELECT COUNT(*) FROM menu")->fetchColumn();
$orderCount = $pdo->query("SELECT COUNT(*) FROM `order` WHERE status = 'pending'")->fetchColumn();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
   
  
</head>
<body>

    <!-- Navigation Bar -->
    <navbar class="navbar">
        <?php include 'layout/navbar.php' ?>
    </navbar>

    <div class="main-content">
        <div class="container mt-3">
            <h1 class="text-center" style=" text-shadow: 10px 5px 7px rgba(5, 10, 5, 0.9);font-size: 40px;color: black;">Admin Dashboard</h1>
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card text-white bg-info mb-3">
                        <div class="card-body">
                            <h5 class="card-title" >Number of Food Menus</h5>
                            <p class="card-text"><?php echo $menuCount; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card text-white bg-danger mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Pending Orders</h5>
                            <p class="card-text"><?php echo $orderCount; ?> pending orders</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-12 text-center">
                    <a href="../menu/manage_menus.php" class="btn btn-primary">Manage Food Menus</a>
                    <a href="../order/view_orders.php" class="btn btn-danger">View Orders</a>
                </div>
            </div>
        </div>
    </div>
    <marquee direction="" style="margin-top:23%;background-color: red;color: white;font-size: 30px;">WELCOME TO OUR ADMIN DASHBOARD</marquee>
    <script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../node_modules/@fortawesome/fontawesome-free/js/all.min.js"></script>

</body>
</html>
