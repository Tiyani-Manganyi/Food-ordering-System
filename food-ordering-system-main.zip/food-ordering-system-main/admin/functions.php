<?php
include __DIR__ . '/../includes/db.php';

// Functions used in the project such as authorization, registration, and login
function registerAdmin($username, $password, $email, $name) {
    global $pdo;
    // Check if the username or email already exists
    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    $admin = $stmt->fetch();

    if ($admin) {
        return false; // Username or email is already in use
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Add new admin to the database
    $stmt = $pdo->prepare("INSERT INTO admin (username, password, email, name) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$username, $hashedPassword, $email, $name]);
}

function loginAdmin($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        return $admin; // Return admin data if login is successful
    }

    return false;
}

function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']);
}
?>
