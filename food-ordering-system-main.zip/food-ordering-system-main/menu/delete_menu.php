<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Check the parameter id
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    // Check if the menu item exists
    $stmt = $pdo->prepare("SELECT * FROM menu_item WHERE menu_item_id = ?");
    $stmt->execute([$id]);
    $menu_item = $stmt->fetch();

    if ($menu_item) {
        // Begin transaction
        $pdo->beginTransaction();
        try {
            // Delete related data in menu table first
            $stmt = $pdo->prepare("DELETE FROM menu WHERE menu_item_id = ?");
            $stmt->execute([$id]);

            // Delete the menu item
            $stmt = $pdo->prepare("DELETE FROM menu_item WHERE menu_item_id = ?");
            $stmt->execute([$id]);

            // Commit transaction
            $pdo->commit();

            $_SESSION['success_message'] = "Menu item has been deleted successfully";
        } catch (Exception $e) {
            // Rollback transaction on error
            $pdo->rollBack();
            $_SESSION['error_message'] = "Failed to delete menu item: " . $e->getMessage();
        }
    } else {
        $_SESSION['error_message'] = "Menu item not found";
    }
} else {
    $_SESSION['error_message'] = "Invalid menu item ID";
}

header('Location: manage_menus.php');
exit();
?>


