<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Check the parameter id
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch menu item data for editing
$stmt = $pdo->prepare("SELECT * FROM menu_item WHERE menu_item_id = ?");
$stmt->execute([$id]);
$menu_item = $stmt->fetch();

if (!$menu_item) {
    die("Menu item data not found for editing");
}

// Process menu item update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $status = $_POST['status']; // Assuming 'status' column instead of 'status_id'
    $image = $menu_item['image']; // Use the existing image by default

    // Check if a new image is uploaded
    if ($_FILES['image']['name']) {
        $image = $_FILES['image']['name'];
        $target = "../upload/img/" . basename($image);
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $image = $target;
        } else {
            $error = "Failed to upload image";
        }
    }

    // Update menu item in the database
    $stmt = $pdo->prepare("UPDATE menu_item SET name = ?, description = ?, price = ?, image = ?, status = ?, category = ? WHERE menu_item_id = ?");
    $stmt->execute([$name, $description, $price, $image, $status, $category, $id]);

    // Redirect to manage_menus.php after update
    header('Location: manage_menus.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Item</title>
    <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../admin/css/style.css">
</head>
<body>

    <!-- Navbar -->
    <?php include '../admin/layout/navbar.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center">Edit Menu Item</h1>
        <?php if (isset($error)) { ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php } ?>
        <form action="edit_menu.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="name" class="form-label">Menu Item Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($menu_item['name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3" required><?php echo htmlspecialchars($menu_item['description']); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price</label>
                <input type="number" class="form-control" id="price" name="price" step="0.01" value="<?php echo htmlspecialchars($menu_item['price']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="category" class="form-label">Category</label>
                <select class="form-select" id="category" name="category" required>
                    <option value="single_dish" <?php echo $menu_item['category'] == 'single_dish' ? 'selected' : ''; ?>>Single Dish</option>
                    <option value="side_dish" <?php echo $menu_item['category'] == 'side_dish' ? 'selected' : ''; ?>>Side Dish</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="available" <?php echo $menu_item['status'] == 'available' ? 'selected' : ''; ?>>Available</option>
                    <option value="unavailable" <?php echo $menu_item['status'] == 'unavailable' ? 'selected' : ''; ?>>Unavailable</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Image</label>
                <input type="file" class="form-control" id="image" name="image">
                <img src="<?php echo htmlspecialchars($menu_item['image']); ?>" alt="Menu Item Image" width="100" class="mt-2">
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    </div>

    <script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
