<?php
include 'includes/db.php'; // Ensure this includes your database connection
include 'includes/functions.php'; // Include necessary functions if required

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['table_number'], $data['items']) && is_array($data['items'])) {
    $table_number = intval($data['table_number']);
    $employee_id = isset($data['employee_id']) ? intval($data['employee_id']) : null;

    // Check if the table number exists in the qr_code table
    $stmt = $pdo->prepare("SELECT table_number FROM qr_code WHERE table_number = ?");
    $stmt->execute([$table_number]);
    $table = $stmt->fetch();

    if ($table) {
        $pdo->beginTransaction();

        try {
            // Insert into `order` table
            $status = 'pending';
            $stmt = $pdo->prepare("INSERT INTO `order` (table_number, status, emp_id) VALUES (?, ?, ?)");
            $stmt->execute([$table_number, $status, $employee_id]);
            $order_id = $pdo->lastInsertId();

            foreach ($data['items'] as $item) {
                if (isset($item['id'], $item['quantity']) && intval($item['quantity']) > 0) {
                    $menu_item_id = intval($item['id']);
                    $quantity = intval($item['quantity']);

                    // Verify that the menu item exists and is available
                    $menuStmt = $pdo->prepare("SELECT menu_item_id FROM menu_item WHERE menu_item_id = ? AND status = 'available'");
                    $menuStmt->execute([$menu_item_id]);
                    $menuItem = $menuStmt->fetch();

                    if ($menuItem) {
                        // Insert into `menu` table
                        $stmt = $pdo->prepare("INSERT INTO menu (menu_item_id, quantity, table_number, order_id) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$menu_item_id, $quantity, $table_number, $order_id]);
                    } else {
                        throw new Exception("Invalid menu item ID or item not available");
                    }
                } else {
                    throw new Exception("Invalid item data");
                }
            }

            $pdo->commit();
            echo json_encode(['success' => true, 'order_id' => $order_id]);
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log('Database error: ' . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid table number']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Incomplete data']);
}
?>
