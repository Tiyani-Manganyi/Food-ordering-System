<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<section id="cart" class="py-5">
    <div class="container">
        <h2 class="text-center mb-4">Shopping Cart</h2>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Menu Item</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="cartItems">
                        <!-- Cart items will be added here -->
                    </tbody>
                </table>
                <div class="text-end">
                    <h4>Total Price: <span id="totalPrice">0</span> ZAR</h4>
                    <button class="btn btn-success" id="checkout">Confirm Order</button>
                    <!-- Button to navigate to my orders page -->
                    <a href="user_orders.php" id="viewOrder" class="btn btn-primary mt-2">Go to My Orders</a>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('checkout').addEventListener('click', function() {
        if (cart.length === 0) {
            alert('Cart is empty');
            return;
        }

        const order = {
            table_id: <?php echo isset($_GET['table_number']) ? intval($_GET['table_number']) : 0; ?>,
            items: cart,
            total: totalPrice
        };

        fetch('checkout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(order)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                localStorage.removeItem('cart');
                alert('Your order has been confirmed');
            } else {
                alert('Error confirming order: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error confirming order');
        });
    });
</script>
</body>
</html>
