<?php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: ../admin/login.php');
    exit();
}

$table_number = isset($_GET['table_number']) ? intval($_GET['table_number']) : 0;

try {
    $stmt = $pdo->query('
        SELECT o.order_id, t.table_number, o.order_time, o.status, mi.menu_item_id, mi.quantity, m.name, m.price 
        FROM `order` o 
        JOIN menu mi ON o.order_id = mi.order_id 
        JOIN menu_item m ON mi.menu_item_id = m.menu_item_id 
        JOIN qr_code t ON o.table_number = t.table_number 
        ORDER BY o.order_id DESC');
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}

// Group orders by table number
$groupedOrders = [];
foreach ($orders as $order) {
    $table_number = $order['table_number'];
    if (!isset($groupedOrders[$table_number])) {
        $groupedOrders[$table_number] = [];
    }
    $order_id = $order['order_id'];
    if (!isset($groupedOrders[$table_number][$order_id])) {
        $groupedOrders[$table_number][$order_id] = [
            'order_id' => $order_id,
            'table_number' => $table_number,
            'order_time' => $order['order_time'],
            'status' => $order['status'],
            'items' => []
        ];
    }
    $groupedOrders[$table_number][$order_id]['items'][] = [
        'name' => $order['name'],
        'quantity' => $order['quantity'],
        'price' => $order['price']
    ];
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Orders</title>
    <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../node_modules/@fortawesome/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .receipt-container {
            margin-bottom: 20px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .receipt-header {
            margin-bottom: 20px;
        }
        .receipt-items table {
            width: 100%;
        }
        .receipt-items th, .receipt-items td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        .receipt-footer {
            text-align: right;
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <!-- Navbar Section -->
    <navbar class="navbar">
        <?php include '../admin/layout/navbar.php' ?>
    </navbar>
    <div class="container mt-5">
        <h1 class="mb-4">Order List</h1>
        <div class="row">
            <div class="col-3">
                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <?php foreach ($groupedOrders as $table_number => $orders): ?>
                        <a class="nav-link <?php echo $table_number == array_key_first($groupedOrders) ? 'active' : ''; ?>" id="v-pills-<?php echo $table_number; ?>-tab" data-bs-toggle="pill" href="#v-pills-<?php echo $table_number; ?>" role="tab" aria-controls="v-pills-<?php echo $table_number; ?>" aria-selected="true">Table: <?php echo $table_number; ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="col-9">
                <div class="tab-content" id="v-pills-tabContent">
                    <?php foreach ($groupedOrders as $table_number => $orders): ?>
                        <div class="tab-pane fade <?php echo $table_number == array_key_first($groupedOrders) ? 'show active' : ''; ?>" id="v-pills-<?php echo $table_number; ?>" role="tabpanel" aria-labelledby="v-pills-<?php echo $table_number; ?>-tab">
                            <?php foreach ($orders as $order): ?>
                            <div class="receipt-container">
                                <div class="receipt-header">
                                    <h5>Order ID: <?php echo htmlspecialchars($order['order_id']); ?></h5>
                                    <p>Table Number: <?php echo htmlspecialchars($order['table_number']); ?></p>
                                    <p>Order Time: <?php echo htmlspecialchars($order['order_time']); ?></p>
                                    <p>Status: <span class="badge <?php echo getBadgeClass($order['status']); ?>"><?php echo htmlspecialchars($order['status']); ?></span></p>
                                </div>
                                <div class="receipt-items">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Menu Item</th>
                                                <th>Quantity</th>
                                                <th>Price</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            $total = 0;
                                            foreach ($order['items'] as $item): 
                                                $itemTotal = $item['quantity'] * $item['price'];
                                                $total += $itemTotal;
                                            ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                                <td><?php echo htmlspecialchars($item['price']); ?> ZAR</td>
                                                <td><?php echo htmlspecialchars(number_format($itemTotal, 2)); ?> ZAR</td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="receipt-footer text-end">
                                    <h5>Total Amount: <?php echo htmlspecialchars(number_format($total, 2)); ?> ZAR</h5>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../node_modules/@fortawesome/fontawesome-free/js/all.min.js"></script>
    <script>
        // Create JavaScript variable from PHP data
        const groupedOrders = <?php echo json_encode($groupedOrders); ?>;

        // Functionality for JavaScript usage
        console.log(groupedOrders);
    </script>
</body>
</html>

<?php
function getBadgeClass($status) {
    switch ($status) {
        case 'pending':
            return 'badge-warning';
        case 'preparing':
            return 'badge-info';
        case 'completed':
            return 'badge-success';
        case 'cancelled':
            return 'badge-danger';
        default:
            return '';
    }
}
?>
